# verifhir/rules/dpdp.py

from verifhir.rules.dpdp_data_principal_rule import DPDPDataPrincipalRule

__all__ = ["DPDPDataPrincipalRule"]