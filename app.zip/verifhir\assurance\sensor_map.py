SENSOR_SUPPORT = {
    "AzureAI-Pii": {
        "Biometric Identifiers",
        "Genetic Data",
        "National Identifiers",
        "Financial Account Numbers",
    },
    "Presidio": {
        "National Identifiers",
        "Financial Account Numbers",
    }
}
