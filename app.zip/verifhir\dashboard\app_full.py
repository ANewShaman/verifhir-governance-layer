import streamlit as st
import os

st.set_page_config(page_title="VeriFHIR Minimal Check")

st.title("Startup OK")

st.write("Streamlit loaded")

st.write("PORT =", os.environ.get("PORT"))

if os.environ.get("AZURE_HEALTH_CHECK") == "1":
    print("HEALTH_OK")

st.success("App started successfully")
