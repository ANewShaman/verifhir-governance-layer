"""
Centralized version constants for audit records.
"""

ENGINE_VERSION = "VeriFHIR-0.9.3"
POLICY_SNAPSHOT_VERSION = "HIPAA-GDPR-DPDP-2025.1"

