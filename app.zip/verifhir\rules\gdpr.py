# verifhir/rules/gdpr.py

from verifhir.rules.gdpr_free_text_identifier_rule import (
    GDPRFreeTextIdentifierRule,
)

__all__ = ["GDPRFreeTextIdentifierRule"]
